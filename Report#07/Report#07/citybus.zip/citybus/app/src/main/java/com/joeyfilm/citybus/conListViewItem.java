package com.joeyfilm.citybus;

public class conListViewItem {
    private String day;
    private String money;
    private String start;
    private String end;

    public String getstart() {
        return start;
    }

    public void setstart(String rowtext1) {
        this.start = rowtext1;
    }

    public String getend() {
        return end;
    }

    public void setend(String rowtext2) {
        this.end = rowtext2;
    }

    public String getday() {
        return day;
    }

    public void setday(String rowtext3) {
        this.day = rowtext3;
    }

    public String getmoney() {
        return money;
    }

    public void setmoney(String rowtext4) {
        this.money = rowtext4;
    }
}
