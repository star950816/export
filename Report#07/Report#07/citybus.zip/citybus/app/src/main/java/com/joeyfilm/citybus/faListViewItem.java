package com.joeyfilm.citybus;

public class faListViewItem {
    private String start;
    private String end;

    public String getstart() {
        return start;
    }

    public void setstart(String rowtext1) {
        this.start = rowtext1;
    }

    public String getend() {
        return end;
    }

    public void setend(String rowtext2) {
        this.end = rowtext2;
    }
}
